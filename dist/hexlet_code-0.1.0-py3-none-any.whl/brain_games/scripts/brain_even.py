#!/usr/bin/env python

import random
import prompt

def main():
    print("Welcome to the Brain Games!")
    name = prompt.string('May I have your name? ')
    print('Hello, {}!'.format(name))
    count = 0
    print('Answer "yes" if the number is even, otherwise answer "no".')


    def question(count):
        number = int(random.randint(1,100))
        print('Question: ', number)
        answer = str(input('Your answer: '))

    number = int(random.randint(1,100))
    print('Question: ', number)
    answer = str(input('Your answer: '))
    while count < 2:
        if number % 2 == 0:
            if answer == 'yes':
                print('Correct!')
                count = count + 1
                question(count)
            else:
                print('"'+answer+'" is wrong answer ;(. Correct answer was "yes".')
                print("Let's try again, "+name+"!")
                return()
        elif number % 2 != 0:
            if answer == 'no':
                print('Correct!')
                count = count + 1
                question(count)
            else:
                print('"'+answer+'" is wrong answer ;(. Correct answer was "no".')
                print("Let's try again, "+name+"!")
                return()
    if count == 2:
        print("Congratulations, ", name,"!")

if __name__ == "__main__":
    main()





