def get_answer():
    pass


def check_answer():
    pass
