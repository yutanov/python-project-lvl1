#!/usr/bin/env python

import prompt
import brain_games.scripts.brain_even as brain_even


def run():
    pass


def game(name):
    for i in range(3):
        number, answer = brain_even.get_answer()
        check_answer = brain_even.is_even(number)
        if check_answer == answer:
            brain_even.right_answer()
        else:
            brain_even.wrong_answer(name, answer, check_answer)
            break
    else:
        brain_even.congratilations(name)


def main():
    print("Welcome to the Brain Games!")
    name = prompt.string('May I have your name? ')
    print('Hello, {}!'.format(name))
    print(COND)
    game(name)

if __name__ == "__main__":
    main()
