import random
import operator


op_list = {'+': operator.add, '-': operator.sub, '*': operator.mul}


def create_number():
    number = int(random.randint(1, 100))
    return number

def choice_op():
    op= random.choice(list(op_list.keys()))
    return op


def example():
    num1 = create_number()
    num2 = create_number()
    operator = op_list[choice_op()]
    ex = operator(num1, num2)
    return ex


